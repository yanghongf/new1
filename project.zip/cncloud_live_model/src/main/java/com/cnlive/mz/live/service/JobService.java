package com.cnlive.mz.live.service;

public interface JobService {
	public void start();
}
