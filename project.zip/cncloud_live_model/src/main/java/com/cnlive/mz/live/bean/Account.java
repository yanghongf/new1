/**
 * Project Name:cnlive_encoding
 * File Name:Account.java
 * Package Name:com.cnlive.encoding.bean
 * Date:2016年3月23日上午11:10:00
 * Copyright (c) 2016, cnlive.com All Rights Reserved.
 *
 */

package com.cnlive.mz.live.bean;

/**
 * TODO: 这里用一句话描述当前类的作用 Date: 2016年3月23日 上午11:10:00 <br/>
 * 
 * @author liujicheng
 * @version V1.0
 * @since JDK 1.6
 */
public class Account {
	private String w_name;
	private String w_password;
	private String s_name;
	private String s_password;

	public String getW_name() {
		return w_name;
	}

	public void setW_name(String w_name) {
		this.w_name = w_name;
	}

	public String getW_password() {
		return w_password;
	}

	public void setW_password(String w_password) {
		this.w_password = w_password;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_password() {
		return s_password;
	}

	public void setS_password(String s_password) {
		this.s_password = s_password;
	}

}
